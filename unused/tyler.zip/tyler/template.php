<?php

include insert_ac.php;
include delete.php;

//server connection
mysql_connect('localhost','tylerguy_tyler','tylerguy!!!');
//select database
mysql_select_db('tylerguy_uark');

$sql="SELECT * FROM Actor order by actorId";

$records=mysql_query($sql);

?>

<html>
    <head>
        <style>
        .fa {color:white;}
        
        #mytable {width:100%;}
        #mytable td {
    font-weight: normal;
	  font-size: 1em;
  -webkit-box-shadow: 0 2px 2px -2px #0E1119;
	   -moz-box-shadow: 0 2px 2px -2px #0E1119;
	        box-shadow: 0 2px 2px -2px #0E1119;
}
#mytable th {
    font-weight: normal;
	  font-size: 1em;
  -webkit-box-shadow: 0 2px 2px -2px #0E1119;
	   -moz-box-shadow: 0 2px 2px -2px #0E1119;
	        box-shadow: 0 2px 2px -2px #0E1119;
}

.container td {
	  font-weight: normal;
	  font-size: 1em;
  -webkit-box-shadow: 0 2px 2px -2px #0E1119;
	   -moz-box-shadow: 0 2px 2px -2px #0E1119;
	        box-shadow: 0 2px 2px -2px #0E1119;
}

.container {
	  text-align: left;
	  overflow: hidden;
	  width: 80%;
	  margin: 0 auto;
      display: table;
      padding: 0 0 8em 0;
}

.container td, .container th {
	  padding-bottom: 2%;
	  padding-top: 2%;
      padding-left:2%;  
}
        
        
        
        #myInput {
    background-image: url('/css/searchicon.png'); /* Add a search icon to input */
    background-repeat: no-repeat; /* Do not repeat the icon image */
    width: 100%; /* Full-width */
    font-size: 14px; /* Increase font-size */
    padding: 12px 20px 12px 40px; /* Add some padding */
    border: 1px solid #ddd; /* Add a grey border */
}

input {
	outline: none;
}
input[type=search] {
	-webkit-appearance: textfield;
	-webkit-box-sizing: content-box;
	font-family: inherit;
	font-size: 100%;
}
input::-webkit-search-decoration,
input::-webkit-search-cancel-button {
	display: none!important; 
}


input[type=search] {
	background: #ededed url(https://static.tumblr.com/ftv85bp/MIXmud4tx/search-icon.png) no-repeat 9px center;!important
	border: solid 1px #ccc!important;
	padding: 9px 10px 9px 32px!important;
	width: 55px!important;
	
	-webkit-border-radius: 10em!important;
	-moz-border-radius: 10em!important;
	border-radius: 10em!important;
	
	-webkit-transition: all .5s!important;
	-moz-transition: all .5s!important;
	transition: all .5s!important;
}
input[type=search]:focus {
	width: 130px!important;
	background-color: #fff!important;
	border-color: #66CC75!important;
	
	-webkit-box-shadow: 0 0 5px rgba(109,207,246,.5)!important;
	-moz-box-shadow: 0 0 5px rgba(109,207,246,.5)!important;
	box-shadow: 0 0 5px rgba(109,207,246,.5)!important;
}


input:-moz-placeholder {
	color: #999!important;
}
input::-webkit-input-placeholder {
	color: #999!important;
}
        
#demo-2 input[type=search] {
	width: 15px!important;
	padding-left: 10px!important;
	color: transparent!important;
	cursor: pointer!important;
}
#demo-2 input[type=search]:hover {
	background-color: #fff!important;
}
#demo-2 input[type=search]:focus {
	width: 150px!important;
	padding-left: 32px!important;
	color: #000!important;
	background-color: #fff!important;
	cursor: auto!important;
}
#demo-2 input:-moz-placeholder {
	color: transparent!important;
}
#demo-2 input::-webkit-input-placeholder {
	color: transparent!important;
}
        
        /**
 * Eric Meyer's Reset CSS v2.0 (https://meyerweb.com/eric/tools/css/reset/)
 * http://cssreset.com
 */
    html, body, div, span, applet, object, iframe,
    h1, h2, h3, h4, h5, h6, p, blockquote, pre,
    a, abbr, acronym, address, big, cite, code,
    del, dfn, em, img, ins, kbd, q, s, samp,
    small, strike, strong, sub, sup, tt, var,
    b, u, i, center,
    dl, dt, dd, ol, ul, li,
    fieldset, form, label, legend,
    table, caption, tbody, tfoot, thead, tr, th, td,
    article, aside, canvas, details, embed,
    figure, figcaption, footer, header, hgroup,
    menu, nav, output, ruby, section, summary,
    time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
    }
    /* HTML5 display-role reset for older browsers */
    article, aside, details, figcaption, figure,
    footer, header, hgroup, menu, nav, section {
    display: block;
    }
    body {
    line-height: 1;
    }
    ol, ul {
    list-style: none;
    }
    blockquote, q {
    quotes: none;
    }
    blockquote:before, blockquote:after,
    q:before, q:after {
    content: '';
    content: none;
    }
    table {
    border-collapse: collapse;
    border-spacing: 0;
    }

/* Reset End */

body {
	background: url("http://www.inboundnow.com/wp-content/uploads/2014/08/bg1.jpg") no-repeat center center fixed;
	background-size: cover;
}

.container {
	margin: 2% auto 0;
}

.container:before { 
	content: url('http://www.arkansasrazorbacks.com/wp-content/themes/arkansasTheme/images/ark-logo-left.png'); 
	display: table;
	margin: 0 auto;
	height: 70px;
	width: 165px;
}

#loginform { 
	background: #e1e3e8;
	border: solid 1px #fff; 
	border-radius:5px; 
	box-shadow: 0 0 7px -1px rgba(0,0,0,0.4);
	height: 75px;
	margin: 115px auto 0; 
	position: relative;
	width: 538px;

}

.login-username .input{ margin-left: 14px;}

.input { 
	background-color: #f5f6f7;
	border: solid 1px #b4b6bd; 
	border-radius:5px; 
	box-sizing: border-box;
	color: #767c8b;
	display: inline-block;
	font: 18px/22px arial;
	float: left;
	height: 55px;  
	margin: 10px 0 9px 14px;
	outline: 0;
	padding-left: 18px;
	transition: box-shadow 0.4s ease;
	width: 248px;
}
.input:focus { 
	box-shadow: 0 0 5px rgba(0,0,0,0.3);
}

.login-password .input { margin-right: 14px;}

.button-primary {
	background-color: #ff6600;
	border: solid 1px transparent; 
	border-radius: 0 6px 6px 0; 
	box-shadow: 0 0 7px -1px rgba(0,0,0,0.5);
	color: #fff;	
	cursor: pointer;
	font-size: 16px;
	font-weight: bold;
	height: 52px;
	left: 538px;
	margin: 12px 0 0 1px;
	outline: none;
	position: absolute;
	text-align: center;
	text-shadow: 0 0 1px #000;
	transition: box-shadow 0.5s ease,text-shadow 0.5s 0.3s;
	width: 46px;
}

.button-primary:hover { 
text-shadow: 0 0 1px rgba(255,255,255,0.8);
box-shadow: 0 0 7px -1px rgba(0,0,0,0.8);
}

#white {color:white;}

#loginform .login-remember {display: none;}

/* Code Ends */
            </style>
            <script type="text/javascript"> 
function DeleteItem() 
{
     var a = confirm("Are you sure to delete this record?");
     if(a) {
         return true;
       }else{
          return false;
            }
}
</script>
            <script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
</script>
        </head>
    <body id="white">
        
        <form id="demo-2">
        <input type="search" id="myInput" onkeyup="myFunction()" placeholder="Search by Name">
        </form>
        
<div id="main" class="container"> 
	
	<table id="myTable">
        <tr>
        <th><h1>ActorID</h1></th>
        <th><h1>Full Name</h1></th>
        <th><h1>Delete?</h1></th>
        </tr>
        
        <?php
        while($actor=mysql_fetch_assoc($records)){
            echo "<tr>";
            
            echo "<td>" . $actor['ActorID']."</td>";
            echo "<td>" . $actor['FirstName']." ";
            echo $actor['LastName']."</td>";
            echo "<td>" . '<a class="btn btn-danger" href="delete.php?del='.$actor['ActorID'].'" onclick="DeleteItem();"><i class="fa fa-ban" aria-hidden="true"></i></a>';
            echo "<tr>";

        }//end loop
        ?>
<script type="text/javascript"> 
function DeleteItem() 
{
     var a = confirm("Are you sure to delete this record?");
     if(a) {
         return true;
       }else{
          return false;
            }
}
</script>
</table>
	
</div>

<table width="400" border="0" align="center" cellpadding="0" cellspacing="1">
<tr><td><form name="form1" method="post" action="insert_ac.php">
<table width="100%" border="0" cellspacing="1" cellpadding="4" color="white">
<tr>
<td colspan="4">Insert new actor</td>
</tr>
<tr>
<select name="table">
  <option value="Actor">Actor</option>
  <option value="saab">Saab</option>
  <option value="fiat">Fiat</option>
  <option value="audi">Audi</option>
</select>
<td width="71">Name</td>
<td width="6">:</td>
<td width="301"><input name="name" type="text" id="name"></td>
</tr>
<tr>
<td>Lastname</td>
<td>:</td>
<td><input name="lastname" type="text" id="lastname"></td>
</tr>
<tr>
<!--<td>ActorID</td>
<td>:</td>
<td><input name="ActorID" type="text" id="ActorID"></td>
</tr>
-->
<tr>
<td colspan="4" align="center"><input type="submit" name="Submit" value="Submit"></td>
</tr>
</td>
</tr>
</table>
</form>

    <script src="https://use.fontawesome.com/9efafc294b.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/randomcolor/0.4.4/randomColor.min.js"></script>
</body>
</html>