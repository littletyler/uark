<?php
$connect=mysqli_connect('localhost','tylerguy_tyler','tylerguy!!!','tylerguy_uark');

if(mysqli_connect_errno($connect))
{
		echo 'Failed to connect';
}

?>